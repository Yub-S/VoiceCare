package com.example.elderlyassistant

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.location.Location
import android.speech.RecognizerIntent
import androidx.activity.ComponentActivity
import androidx.activity.result.ActivityResult
import androidx.activity.result.ActivityResultCallback
import androidx.activity.result.ActivityResultLauncher
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import com.google.android.gms.location.LocationServices
import com.google.android.gms.tasks.Tasks
import kotlinx.coroutines.*
import java.util.*
import kotlin.coroutines.Continuation
import kotlin.coroutines.resume
import kotlin.coroutines.suspendCoroutine

class EmergencyHandler(
    private val context: Context,
    private val textToSpeechManager: TextToSpeechManager
) {
    private var _callingAgent: CallingAgent? = null
    private var _messageService: MessageService? = null
    private val fusedLocationClient = LocationServices.getFusedLocationProviderClient(context)
    private val emergencyNumber = "911"
    private var speechRecognitionContinuation: Continuation<String>? = null
    private lateinit var speechRecognizerLauncher: ActivityResultLauncher<Intent>

    fun setDependencies(callingAgent: CallingAgent, messageService: MessageService) {
        _callingAgent = callingAgent
        _messageService = messageService

        // Set up circular references
        callingAgent.setEmergencyHandler(this)
        messageService.setEmergencyHandler(this)
    }

    protected val callingAgent: CallingAgent
        get() = _callingAgent ?: throw IllegalStateException("CallingAgent not initialized")

    protected val messageService: MessageService
        get() = _messageService ?: throw IllegalStateException("MessageService not initialized")

    init {
        setupSpeechRecognition()
    }

    fun setupSpeechRecognition() {
        if (context is ComponentActivity) {
            speechRecognizerLauncher = context.registerForActivityResult(
                ActivityResultContracts.StartActivityForResult(),
                ActivityResultCallback { result: ActivityResult ->
                    if (result.resultCode == Activity.RESULT_OK) {
                        val spokenText = result.data?.getStringArrayListExtra(
                            RecognizerIntent.EXTRA_RESULTS
                        )?.firstOrNull() ?: ""
                        speechRecognitionContinuation?.resume(spokenText)
                    } else {
                        speechRecognitionContinuation?.resume("")
                    }
                    speechRecognitionContinuation = null
                }
            )
        } else {
            throw IllegalArgumentException("Context must be a ComponentActivity")
        }
    }

    suspend fun listenForResponse(): String = suspendCoroutine { continuation ->
        speechRecognitionContinuation = continuation

        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL,
                RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault())
            putExtra(RecognizerIntent.EXTRA_PROMPT, "Speak now")
        }

        try {
            speechRecognizerLauncher.launch(intent)
        } catch (e: Exception) {
            e.printStackTrace()
            continuation.resume("")
            speechRecognitionContinuation = null
        }
    }

    suspend fun handleEmergency(situation: String) {
        val location = getCurrentLocation()
        notifyCloseContacts(situation, location)
        val canUserTalk = askUserIfCanTalk()

        if (canUserTalk) {
            callingAgent.initiateCall(emergencyNumber) { status ->
                textToSpeechManager.speak(status)
            }
        } else {
            initiateAICall(situation, location)
        }
    }

    private suspend fun getCurrentLocation(): Location? {
        return withContext(Dispatchers.IO) {
            if (ContextCompat.checkSelfPermission(
                    context,
                    Manifest.permission.ACCESS_FINE_LOCATION
                ) == PackageManager.PERMISSION_GRANTED
            ) {
                try {
                    Tasks.await(fusedLocationClient.lastLocation)
                } catch (e: Exception) {
                    null
                }
            } else {
                null
            }
        }
    }

    private suspend fun notifyCloseContacts(situation: String, location: Location?) {
        val emergencyContacts = getEmergencyContacts()
        val locationString = location?.let { "Lat: ${it.latitude}, Long: ${it.longitude}" } ?: "Unknown"
        val message = "Emergency: $situation. Location: $locationString"

        emergencyContacts.forEach { contact ->
            messageService.sendSms(contact, message)
        }
    }

    private suspend fun askUserIfCanTalk(): Boolean {
        for (i in 1..2) {
            textToSpeechManager.speak("Can you talk to emergency services? Say yes or no.")
            delay(1000)

            val response = withContext(Dispatchers.IO) {
                listenForResponse()
            }

            if (response.equals("yes", ignoreCase = true)) {
                return true
            }

            delay(2000)
        }
        return false
    }

    private suspend fun initiateAICall(situation: String, location: Location?) {
        callingAgent.initiateCall(emergencyNumber) { status ->
            textToSpeechManager.speak(status)
        }

        delay(10000)

        val emergencyMessage = generateEmergencyMessage(situation, location)

        repeat(3) { iteration ->
            if (iteration > 0) {
                textToSpeechManager.speak("Repeating the message.")
                delay(3000)
            }
            textToSpeechManager.speak(emergencyMessage)
            delay(calculateMessageDuration(emergencyMessage))
        }

        textToSpeechManager.speak("This emergency message has been repeated 3 times. The call will now end. If you need further assistance, please call back.")
        delay(5000)
    }

    private fun generateEmergencyMessage(situation: String, location: Location?): String {
        val locationString = location?.let { "at latitude ${it.latitude} and longitude ${it.longitude}" } ?: "at an unknown location"
        return """
            This is an automated emergency call on behalf of ${getUserName()}, age ${getUserAge()}.It will repeat three times.
            The situation is: $situation.
            The person is located $locationString.
            Medical conditions include: ${getUserMedicalConditions()}.
            Please send immediate assistance.
        """.trimIndent()
    }

    private fun calculateMessageDuration(message: String): Long {
        return (message.length * 100L) + 2000L
    }

    private fun getUserName(): String = "John Doe"
    private fun getUserAge(): Int = 75
    private fun getUserMedicalConditions(): String = "hypertension, diabetes"
    private fun getEmergencyContacts(): List<String> = listOf("9869665428")

    companion object {
        private const val SPEECH_REQUEST_CODE = 0
    }
}