package com.example.elderlyassistant

import android.content.ContentResolver
import android.content.ContentUris
import android.content.ContentValues
import android.content.Context
import android.provider.CalendarContract
import android.util.Log
import java.util.*
import java.text.SimpleDateFormat
import android.Manifest
import android.content.pm.PackageManager
import androidx.core.content.ContextCompat
import android.provider.CalendarContract.Events
import android.provider.CalendarContract.Reminders
import android.provider.CalendarContract.Calendars
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

class ReminderSet(
    private val context: Context,
    private val textToSpeechManager: TextToSpeechManager
) {
    private val TAG = "ReminderSet"

    data class ReminderInfo(
        val title: String,
        val startTime: Calendar,
        val endTime: Calendar,
        val description: String?,
        val reminderMinutes: Int
    )

    data class CalendarInfo(
        val id: Long,
        val accountName: String,
        val displayName: String
    )

    suspend fun parseAndSetReminder(llmResponse: String): Boolean {
        return try {
            Log.d(TAG, "Parsing LLM response: $llmResponse")
            val reminderInfo = parseLLMResponse(llmResponse)
            if (reminderInfo != null) {
                Log.d(TAG, "Parsed reminder info: $reminderInfo")
                setGoogleCalendarReminder(reminderInfo)
            } else {
                Log.e(TAG, "Failed to parse LLM response: $llmResponse")
                textToSpeechManager.speak("I'm sorry, but I couldn't understand the reminder details. Please try again.")
                false
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error setting reminder", e)
            textToSpeechManager.speak("I'm sorry, but I couldn't set the reminder due to an error: ${e.message}")
            false
        }
    }

    private fun parseLLMResponse(llmResponse: String): ReminderInfo? {
        try {
            val cleanResponse = llmResponse.removePrefix("Reminder: ")
            val components = cleanResponse.split(" at ")
            if (components.size != 2) return null

            val title = components[0]
            val timeStr = components[1]

            val calendar = parseTime(timeStr) ?: return null

            val endTime = (calendar.clone() as Calendar).apply { add(Calendar.HOUR, 1) }

            return ReminderInfo(
                title = title,
                startTime = calendar,
                endTime = endTime,
                description = "Voice reminder: $title",
                reminderMinutes = 15 // Default reminder 15 minutes before
            )
        } catch (e: Exception) {
            Log.e(TAG, "Error parsing LLM response", e)
            return null
        }
    }

    private fun parseTime(timeStr: String): Calendar? {
        val calendar = Calendar.getInstance()
        try {
            val timePattern = Regex("""(\d{1,2})(?::(\d{2}))?\s*(am|pm)?""", RegexOption.IGNORE_CASE)
            val match = timePattern.find(timeStr)

            if (match != null) {
                var hour = match.groupValues[1].toInt()
                val minute = match.groupValues[2].takeIf { it.isNotEmpty() }?.toInt() ?: 0
                val ampm = match.groupValues[3].lowercase()

                // Convert to 24-hour format
                hour = when {
                    ampm == "pm" && hour != 12 -> hour + 12
                    ampm == "am" && hour == 12 -> 0
                    else -> hour
                }

                calendar.set(Calendar.HOUR_OF_DAY, hour)
                calendar.set(Calendar.MINUTE, minute)
                calendar.set(Calendar.SECOND, 0)
                calendar.set(Calendar.MILLISECOND, 0)

                // If time today has passed, set for tomorrow
                if (calendar.timeInMillis < System.currentTimeMillis()) {
                    calendar.add(Calendar.DAY_OF_YEAR, 1)
                }

                return calendar
            }
            return null
        } catch (e: Exception) {
            Log.e(TAG, "Error parsing time", e)
            return null
        }
    }

    private suspend fun setGoogleCalendarReminder(reminderInfo: ReminderInfo): Boolean = withContext(Dispatchers.IO) {
        try {
            if (!checkCalendarPermissions()) {
                throw SecurityException("Calendar permissions not granted")
            }

            val googleCalendars = getGoogleCalendars()
            if (googleCalendars.isEmpty()) {
                throw Exception("No Google calendars found")
            }

            val calendarToUse = googleCalendars.first()
            Log.d(TAG, "Using Google Calendar: ${calendarToUse.displayName} (${calendarToUse.accountName})")

            val eventValues = ContentValues().apply {
                put(Events.CALENDAR_ID, calendarToUse.id)
                put(Events.TITLE, reminderInfo.title)
                put(Events.DESCRIPTION, reminderInfo.description)
                put(Events.DTSTART, reminderInfo.startTime.timeInMillis)
                put(Events.DTEND, reminderInfo.endTime.timeInMillis)
                put(Events.ALL_DAY, 0)
                put(Events.HAS_ALARM, 1)
                put(Events.EVENT_TIMEZONE, TimeZone.getDefault().id)
            }

            val eventUri = context.contentResolver.insert(Events.CONTENT_URI, eventValues)
            val eventId = eventUri?.lastPathSegment?.toLong() ?: throw Exception("Failed to create event")

            Log.d(TAG, "Created event with ID: $eventId")

            // Set reminder
            val reminderValues = ContentValues().apply {
                put(Reminders.EVENT_ID, eventId)
                put(Reminders.METHOD, Reminders.METHOD_ALERT)
                put(Reminders.MINUTES, reminderInfo.reminderMinutes)
            }
            context.contentResolver.insert(Reminders.CONTENT_URI, reminderValues)

            // Verify the event and reminder were created
            val (eventExists, reminderExists) = verifyEventAndReminder(eventId)
            if (!eventExists || !reminderExists) {
                throw Exception("Event or reminder creation failed verification")
            }

            val timeStr = SimpleDateFormat("hh:mm a", Locale.getDefault()).format(reminderInfo.startTime.time)
            val dateStr = SimpleDateFormat("EEEE, MMMM d", Locale.getDefault()).format(reminderInfo.startTime.time)

            val confirmationMessage = "I've set a reminder for ${reminderInfo.title} on $dateStr at $timeStr. " +
                    "You'll be notified ${reminderInfo.reminderMinutes} minutes before the event. " +
                    "This event has been added to your Google Calendar for the account ${calendarToUse.accountName}."

            Log.d(TAG, "Reminder set successfully: $confirmationMessage")
            textToSpeechManager.speak(confirmationMessage)

            return@withContext true
        } catch (e: Exception) {
            Log.e(TAG, "Error setting Google calendar reminder", e)
            textToSpeechManager.speak("I'm sorry, but I couldn't set the reminder in your Google Calendar. ${e.message}")
            return@withContext false
        }
    }

    private fun verifyEventAndReminder(eventId: Long): Pair<Boolean, Boolean> {
        val eventUri = ContentUris.withAppendedId(Events.CONTENT_URI, eventId)
        val eventProjection = arrayOf(Events._ID, Events.TITLE, Events.DTSTART)
        val eventExists = context.contentResolver.query(eventUri, eventProjection, null, null, null)?.use { cursor ->
            cursor.moveToFirst() && cursor.count > 0
        } ?: false

        val reminderExists = if (eventExists) {
            val reminderUri = Reminders.CONTENT_URI
            val selection = "${Reminders.EVENT_ID} = ?"
            val selectionArgs = arrayOf(eventId.toString())
            val reminderProjection = arrayOf(Reminders._ID, Reminders.EVENT_ID, Reminders.MINUTES)
            context.contentResolver.query(reminderUri, reminderProjection, selection, selectionArgs, null)?.use { cursor ->
                cursor.moveToFirst() && cursor.count > 0
            } ?: false
        } else {
            false
        }

        Log.d(TAG, "Event exists: $eventExists, Reminder exists: $reminderExists")
        return Pair(eventExists, reminderExists)
    }

    private fun checkCalendarPermissions(): Boolean {
        return ContextCompat.checkSelfPermission(context, Manifest.permission.READ_CALENDAR) == PackageManager.PERMISSION_GRANTED &&
                ContextCompat.checkSelfPermission(context, Manifest.permission.WRITE_CALENDAR) == PackageManager.PERMISSION_GRANTED
    }

    private fun getGoogleCalendars(): List<CalendarInfo> {
        val projection = arrayOf(
            Calendars._ID,
            Calendars.ACCOUNT_NAME,
            Calendars.CALENDAR_DISPLAY_NAME,
            Calendars.OWNER_ACCOUNT
        )
        val selection = "(${Calendars.ACCOUNT_TYPE} = ?)"
        val selectionArgs = arrayOf("com.google")
        val googleCalendars = mutableListOf<CalendarInfo>()

        context.contentResolver.query(Calendars.CONTENT_URI, projection, selection, selectionArgs, null)?.use { cursor ->
            while (cursor.moveToNext()) {
                val calendarId = cursor.getLong(0)
                val accountName = cursor.getString(1)
                val displayName = cursor.getString(2)
                val ownerAccount = cursor.getString(3)

                Log.d(TAG, "Found Google Calendar: $displayName (Account: $accountName, Owner: $ownerAccount)")
                googleCalendars.add(CalendarInfo(calendarId, accountName, displayName))
            }
        }

        if (googleCalendars.isEmpty()) {
            Log.e(TAG, "No Google calendars found")
        } else {
            Log.d(TAG, "Found ${googleCalendars.size} Google calendars")
        }

        return googleCalendars
    }
}