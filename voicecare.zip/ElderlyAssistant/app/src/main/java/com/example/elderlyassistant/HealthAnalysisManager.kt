package com.example.elderlyassistant

import android.content.Context
import android.content.Intent
import android.util.Log
import androidx.activity.result.ActivityResultLauncher
import com.google.android.gms.auth.api.signin.GoogleSignIn
import com.google.android.gms.auth.api.signin.GoogleSignInOptions
import com.google.android.gms.fitness.Fitness
import com.google.android.gms.fitness.FitnessOptions
import com.google.android.gms.fitness.data.DataType
import com.google.android.gms.fitness.request.DataReadRequest
import com.google.ai.client.generativeai.GenerativeModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withContext
import java.util.Calendar
import java.util.concurrent.TimeUnit

class HealthAnalysisManager(private val context: Context) {
    private val TAG = "HealthAnalysisManager"
    private val fitnessOptions = FitnessOptions.builder()
        .addDataType(DataType.TYPE_STEP_COUNT_DELTA, FitnessOptions.ACCESS_READ)
        .addDataType(DataType.TYPE_CALORIES_EXPENDED, FitnessOptions.ACCESS_READ)
        .addDataType(DataType.TYPE_HEART_RATE_BPM, FitnessOptions.ACCESS_READ)
        .build()

    private var hasPermissions = false

    private fun requestPermissions(activity: android.app.Activity) {
        val account = GoogleSignIn.getAccountForExtension(context, fitnessOptions)

        if (!GoogleSignIn.hasPermissions(account, fitnessOptions)) {
            Log.d(TAG, "Requesting Google Fit permissions")
            GoogleSignIn.requestPermissions(
                activity,
                GOOGLE_FIT_PERMISSIONS_REQUEST_CODE,
                account,
                fitnessOptions)
        } else {
            Log.d(TAG, "Already has Google Fit permissions")
            hasPermissions = true
        }
    }

    private fun checkPermissions(): Boolean {
        val account = GoogleSignIn.getLastSignedInAccount(context)
        if (account == null) {
            Log.d(TAG, "No Google account found")
            return false
        }

        val hasPermissions = GoogleSignIn.hasPermissions(account, fitnessOptions)
        Log.d(TAG, "Has Google Fit permissions: $hasPermissions")
        return hasPermissions
    }

    fun handlePermissionResult(result: Boolean) {
        hasPermissions = result
        Log.d(TAG, "Permission result handled: $result")
    }

    suspend fun analyzeHealth(query: String, activity: android.app.Activity): String {
        return withContext(Dispatchers.IO) {
            if (!hasPermissions || !checkPermissions()) {
                requestPermissions(activity)
                return@withContext "To analyze your health data, I need permission to access Google Fit. I've initiated the permission request. Please grant the necessary permissions and try again."
            }

            try {
                val account = GoogleSignIn.getAccountForExtension(context, fitnessOptions)
                val endTime = Calendar.getInstance().timeInMillis
                val startTime = endTime - TimeUnit.DAYS.toMillis(7) // Last 7 days

                val dataReadRequest = DataReadRequest.Builder()
                    .read(DataType.TYPE_STEP_COUNT_DELTA)
                    .read(DataType.TYPE_CALORIES_EXPENDED)
                    .read(DataType.TYPE_HEART_RATE_BPM)
                    .setTimeRange(startTime, endTime, TimeUnit.MILLISECONDS)
                    .build()

                val response = Fitness.getHistoryClient(context, account)
                    .readData(dataReadRequest)
                    .await()

                var totalSteps = 0
                var totalCalories = 0f
                var avgHeartRate = 0f
                var heartRateReadings = 0

                for (dataSet in response.dataSets) {
                    for (dp in dataSet.dataPoints) {
                        when (dp.dataType) {
                            DataType.TYPE_STEP_COUNT_DELTA -> totalSteps += dp.getValue(dp.dataType.fields[0]).asInt()
                            DataType.TYPE_CALORIES_EXPENDED -> totalCalories += dp.getValue(dp.dataType.fields[0]).asFloat()
                            DataType.TYPE_HEART_RATE_BPM -> {
                                avgHeartRate += dp.getValue(dp.dataType.fields[0]).asFloat()
                                heartRateReadings++
                            }
                        }
                    }
                }

                val avgStepsPerDay = totalSteps / 7
                val avgCaloriesPerDay = totalCalories / 7
                avgHeartRate = if (heartRateReadings > 0) avgHeartRate / heartRateReadings else 0f

                val healthData = """
                    Over the last 7 days:
                    - Average daily steps: $avgStepsPerDay
                    - Average daily calories burned: ${"%.1f".format(avgCaloriesPerDay)}
                    - Average heart rate: ${"%.1f".format(avgHeartRate)} BPM
                """.trimIndent()

                analyzeHealthWithLLM(healthData, query)
            } catch (e: Exception) {
                Log.e(TAG, "Error analyzing health data: ${e.message}")
                "I'm sorry, but I encountered an error while analyzing your health data: ${e.message}"
            }
        }
    }

    private suspend fun analyzeHealthWithLLM(healthData: String, query: String): String {
        return withContext(Dispatchers.Default) {
            val generativeModel = GenerativeModel(
                modelName = "gemini-1.5-pro",
                apiKey = "AIzaSyDESVRn8spVAygvw2ewayvt1PTq56NrfP8"
            )

            val prompt = """
                As a health assistant, analyze the following health data and provide insights based on the user's query. Be empathetic and encouraging in your response.

                Health Data:
                $healthData

                User Query: $query

                Provide a concise analysis and recommendations based on the data and query. If the data seems insufficient or concerning, suggest consulting a healthcare professional.
            """.trimIndent()

            try {
                val response = generativeModel.generateContent(prompt)
                response.text?.trim() ?: "I'm sorry, but I couldn't generate a health analysis at this time. Please try again later."
            } catch (e: Exception) {
                Log.e(TAG, "Error generating health analysis: ${e.message}")
                "I apologize, but I encountered an error while analyzing your health data. Please try again later."
            }
        }
    }

    companion object {
        const val GOOGLE_FIT_PERMISSIONS_REQUEST_CODE = 2002
    }
}