package com.example.elderlyassistant

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.location.Location
import android.util.Log
import androidx.core.app.ActivityCompat
import com.google.android.gms.location.LocationServices
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.coroutines.tasks.await
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

class PlaceFinder(
    private val context: Context,
    private val callingAgent: CallingAgent
) {
    private val TAG = "PlaceFinder"
    private val API_KEY = "734584fe88a948d8900bb5160ea95dc5"
    private val fusedLocationClient = LocationServices.getFusedLocationProviderClient(context)

    enum class PlaceType(val apiCategory: String) {
        RESTAURANT("catering.restaurant"),
        HOSPITAL("healthcare.hospital"),
        PHARMACY("healthcare.pharmacy"),
        CLINIC("healthcare.clinic"),
        DOCTOR("healthcare.doctor");

        companion object {
            fun fromString(type: String): PlaceType? {
                return when (type.lowercase()) {
                    "restaurant" -> RESTAURANT
                    "hospital" -> HOSPITAL
                    "pharmacy" -> PHARMACY
                    "clinic" -> CLINIC
                    "doctor" -> DOCTOR
                    else -> null
                }
            }
        }
    }

    suspend fun findNearbyPlaceAndCall(
        placeType: PlaceType,
        updateStatusText: (String) -> Unit,
        updateDebugInfo: (String) -> Unit
    ): Boolean {
        updateStatusText("Searching for nearby ${placeType.name.lowercase()}s...")
        return withContext(Dispatchers.IO) {
            try {
                Log.d(TAG, "Starting place search process for ${placeType.name}")
                updateDebugInfo("Starting place search for ${placeType.name}")

                val location = getLastKnownLocation(updateStatusText, updateDebugInfo)
                if (location == null) {
                    Log.e(TAG, "Unable to get location")
                    updateStatusText("Unable to get your location. Please check your location settings.")
                    updateDebugInfo("Location retrieval failed")
                    return@withContext false
                }

                Log.d(TAG, "Got location: ${location.latitude}, ${location.longitude}")
                updateDebugInfo("Location: ${location.latitude}, ${location.longitude}")

                val searchUrl = buildPlacesSearchUrl(location, placeType)
                Log.d(TAG, "Search URL: $searchUrl")
                updateDebugInfo("API URL: $searchUrl")

                val placeWithPhone = findNearestPlaceWithPhone(searchUrl, placeType, updateStatusText, updateDebugInfo)
                if (placeWithPhone == null) {
                    Log.e(TAG, "No ${placeType.name.lowercase()} with phone number found")
                    updateDebugInfo("No ${placeType.name.lowercase()} with phone number found")
                    return@withContext false
                }

                val (_, phoneNumber, name) = placeWithPhone
                Log.d(TAG, "Found ${placeType.name.lowercase()}: $name with phone: $phoneNumber")
                updateDebugInfo("Found place: $name, Phone: $phoneNumber")

                val formattedPhoneNumber = phoneNumber.replace(Regex("[^0-9+]"), "")
                if (formattedPhoneNumber.isEmpty()) {
                    Log.e(TAG, "Invalid phone number format")
                    updateStatusText("Invalid phone number format")
                    updateDebugInfo("Invalid phone number format")
                    return@withContext false
                }

                Log.d(TAG, "Formatted phone number: $formattedPhoneNumber")
                updateStatusText("Found ${placeType.name.lowercase()}: $name. Initiating call...")

                withContext(Dispatchers.Main) {
                    try {
                        callingAgent.initiateCall(formattedPhoneNumber, updateStatusText)
                        true
                    } catch (e: Exception) {
                        Log.e(TAG, "Error making call: ${e.message}")
                        updateStatusText("Error making call: ${e.message}")
                        updateDebugInfo("Call initiation failed: ${e.message}")
                        false
                    }
                }
            } catch (e: Exception) {
                Log.e(TAG, "Error in findNearbyPlaceAndCall: ${e.message}")
                updateStatusText("Error finding ${placeType.name.lowercase()}: ${e.message}")
                updateDebugInfo("Error in findNearbyPlaceAndCall: ${e.message}")
                false
            }
        }
    }

    private fun buildPlacesSearchUrl(location: Location, placeType: PlaceType): String {
        val baseUrl = "https://api.geoapify.com/v2/places"
        val radius = 5000 // Search radius in meters
        val categories = URLEncoder.encode(placeType.apiCategory, "UTF-8")
        return "$baseUrl?categories=$categories" +
                "&filter=circle:${location.longitude},${location.latitude},$radius" +
                "&limit=20" +
                "&apiKey=$API_KEY"
    }

    private suspend fun findNearestPlaceWithPhone(
        url: String,
        placeType: PlaceType,
        updateStatusText: (String) -> Unit,
        updateDebugInfo: (String) -> Unit
    ): Triple<String, String, String>? {
        return withContext(Dispatchers.IO) {
            try {
                val connection = URL(url).openConnection() as HttpURLConnection
                connection.requestMethod = "GET"

                val response = connection.inputStream.bufferedReader().use { it.readText() }
                val jsonResult = JSONObject(response)
                val features = jsonResult.getJSONArray("features")

                updateDebugInfo("API Response: ${features.length()} places found")

                for (i in 0 until features.length()) {
                    val place = features.getJSONObject(i)
                    val properties = place.getJSONObject("properties")

                    val phoneNumber = properties.optString("contact:phone")
                    val name = properties.optString("name", placeType.name.capitalize())
                    val placeId = properties.optString("place_id")

                    updateDebugInfo("Place ${i + 1}: $name, Phone: $phoneNumber")

                    if (phoneNumber.isNotEmpty() && phoneNumber != "null") {
                        updateStatusText("Found ${placeType.name.lowercase()} with phone number: $name")
                        return@withContext Triple(placeId, phoneNumber, name)
                    }
                }

                updateStatusText("No ${placeType.name.lowercase()}s with phone numbers found nearby")
                updateDebugInfo("No places with valid phone numbers found")
                null
            } catch (e: Exception) {
                Log.e(TAG, "Error searching ${placeType.name.lowercase()}s: ${e.message}")
                updateStatusText("Error searching ${placeType.name.lowercase()}s: ${e.message}")
                updateDebugInfo("API call failed: ${e.message}")
                null
            }
        }
    }

    private suspend fun getLastKnownLocation(
        updateStatusText: (String) -> Unit,
        updateDebugInfo: (String) -> Unit
    ): Location? {
        return withContext(Dispatchers.IO) {
            if (ActivityCompat.checkSelfPermission(
                    context,
                    Manifest.permission.ACCESS_FINE_LOCATION
                ) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(
                    context,
                    Manifest.permission.ACCESS_COARSE_LOCATION
                ) != PackageManager.PERMISSION_GRANTED
            ) {
                Log.e(TAG, "Location permission not granted")
                updateStatusText("Location permission not granted. Please grant location permission in settings.")
                updateDebugInfo("Location permission not granted")
                return@withContext null
            }

            try {
                Log.d(TAG, "Attempting to get last known location")
                updateDebugInfo("Attempting to get last known location")
                val locationResult = fusedLocationClient.lastLocation.await()
                if (locationResult == null) {
                    Log.d(TAG, "Last known location is null, trying to get current location")
                    updateStatusText("Unable to get your last known location. Trying to get current location...")
                    updateDebugInfo("Last known location is null, requesting current location")
                    val newLocationResult = fusedLocationClient.getCurrentLocation(100, null).await()
                    if (newLocationResult == null) {
                        Log.e(TAG, "Unable to get current location")
                        updateStatusText("Unable to get your current location. Please check your location settings.")
                        updateDebugInfo("Failed to get current location")
                        null
                    } else {
                        Log.d(TAG, "Got current location")
                        updateDebugInfo("Current location obtained")
                        newLocationResult
                    }
                } else {
                    Log.d(TAG, "Got last known location")
                    updateDebugInfo("Last known location obtained")
                    locationResult
                }
            } catch (e: Exception) {
                Log.e(TAG, "Error getting location: ${e.message}")
                updateStatusText("Error getting location: ${e.message}")
                updateDebugInfo("Location retrieval error: ${e.message}")
                null
            }
        }
    }
}