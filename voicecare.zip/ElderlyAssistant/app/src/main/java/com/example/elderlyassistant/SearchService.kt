package com.example.elderlyassistant

import retrofit2.Response
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.http.Body
import retrofit2.http.POST
import kotlinx.coroutines.*
import android.util.Log
import com.google.ai.client.generativeai.GenerativeModel
import org.threeten.bp.LocalDate
import org.threeten.bp.format.DateTimeFormatter

data class TavilyRequest(
    val api_key: String,
    val query: String,
    val include_images: Boolean = false,
    val max_results: Int = 5
)

data class TavilyResponse(
    val results: List<SearchResult>
)

data class SearchResult(
    val title: String,
    val url: String,
    val content: String
)

interface TavilyApi {
    @POST("search")
    suspend fun search(
        @Body requestBody: TavilyRequest
    ): Response<TavilyResponse>
}

class SearchService(
    private val tavilyApiKey: String,
    private val geminiApiKey: String,
    private val textToSpeechManager: TextToSpeechManager
) {
    private val TAG = "SearchService"

    private val api: TavilyApi by lazy {
        Retrofit.Builder()
            .baseUrl("https://api.tavily.com/")
            .addConverterFactory(GsonConverterFactory.create())
            .build()
            .create(TavilyApi::class.java)
    }

    private val generativeModel by lazy {
        GenerativeModel(
            modelName = "gemini-1.5-flash",
            apiKey = geminiApiKey
        )
    }

    suspend fun handleSearchQuery(query: String) {
        try {
            // Process the query
            val processedQuery = processQuery(query)

            // Get search results
            val searchResults = searchInternet(processedQuery)
            if (searchResults.startsWith("Sorry")) {
                textToSpeechManager.speak(searchResults)
                return
            }

            // Summarize results
            val summary = summarizeResults(searchResults)

            // Speak result
            textToSpeechManager.speak(summary)

        } catch (e: Exception) {
            val errorMessage = "Sorry, there was an error while searching: ${e.message}"
            textToSpeechManager.speak(errorMessage)
            Log.e(TAG, "Error in handleSearchQuery", e)
        }
    }


    private fun processQuery(query: String): String {
        val today = LocalDate.now()
        val formatter = DateTimeFormatter.ofPattern("MMMM d, yyyy")
        val formattedDate = today.format(formatter)

        return query
            .replace("today", formattedDate, ignoreCase = true)
            .replace("yesterday", today.minusDays(1).format(formatter), ignoreCase = true)
            .replace("tomorrow", today.plusDays(1).format(formatter), ignoreCase = true)
    }

    private suspend fun searchInternet(query: String): String {
        return withContext(Dispatchers.IO) {
            try {
                val request = TavilyRequest(
                    api_key = tavilyApiKey,
                    query = query
                )

                val response = api.search(request)
                if (!response.isSuccessful) {
                    return@withContext "Sorry, I couldn't search for that information right now."
                }

                val searchResults = response.body()?.results ?: emptyList()
                if (searchResults.isEmpty()) {
                    return@withContext "I couldn't find any relevant information about that."
                }

                // Combine search results into a single text
                searchResults.joinToString("\n\n") { result ->
                    "${result.title}:\n${result.content}"
                }

            } catch (e: Exception) {
                Log.e(TAG, "Error in searchInternet", e)
                "Sorry, there was an error while searching: ${e.message}"
            }
        }
    }

    private suspend fun summarizeResults(searchResults: String): String {
        return withContext(Dispatchers.IO) {
            try {
                val summarizationPrompt = """
                    Summarize the following information in a clear, concise way that would be easy 
                    for an elderly person to understand. Keep medical terms simple and explain any 
                    technical concepts. Format the response in short, easy-to-understand sentences:
                    
                    $searchResults
                """.trimIndent()

                generativeModel.generateContent(summarizationPrompt).text
                    ?: "Sorry, I couldn't summarize the information."

            } catch (e: Exception) {
                Log.e(TAG, "Error in summarizeResults", e)
                "Sorry, I couldn't create a summary of the information."
            }
        }
    }
}