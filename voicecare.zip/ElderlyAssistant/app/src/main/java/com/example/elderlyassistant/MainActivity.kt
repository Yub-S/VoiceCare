package com.example.elderlyassistant

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.speech.RecognizerIntent
import android.util.Log
import com.jakewharton.threetenabp.AndroidThreeTen
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.lifecycleScope
import com.example.elderlyassistant.ui.theme.ElderlyAssistantTheme
import com.google.ai.client.generativeai.GenerativeModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import android.app.Activity
import androidx.compose.foundation.background
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Mic
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.style.TextAlign
import java.util.*

class MainViewModel : ViewModel() {
    private val _statusText = MutableStateFlow("Press the microphone to speak")
    val statusText: StateFlow<String> = _statusText.asStateFlow()
    private val _llmResponse = MutableStateFlow<String?>(null)
    val llmResponse: StateFlow<String?> = _llmResponse.asStateFlow()

    private val _debugInfo = MutableStateFlow<String?>(null)
    val debugInfo: StateFlow<String?> = _debugInfo.asStateFlow()

    fun updateStatusText(newStatus: String) {
        viewModelScope.launch {
            _statusText.value = newStatus
        }
    }

    fun updateLlmResponse(response: String?) {
        viewModelScope.launch {
            _llmResponse.value = response
        }
    }

    fun updateDebugInfo(info: String?) {
        viewModelScope.launch {
            _debugInfo.value = info
        }
    }
}

class MainActivity : ComponentActivity() {
    private val TAG = "MainActivity"
    private val SPEECH_REQUEST_CODE = 0
    private val SMS_PERMISSION_REQUEST_CODE = 1002
    private val CALL_PERMISSION_REQUEST_CODE = 1
    private val CALENDAR_PERMISSION_REQUEST_CODE = 1003
    private val READ_CONTACTS_PERMISSION_REQUEST_CODE = 2
    private val LOCATION_PERMISSION_REQUEST_CODE = 1001
    private lateinit var healthAnalysisManager: HealthAnalysisManager
    private val viewModel: MainViewModel by viewModels()
    private lateinit var textToSpeechManager: TextToSpeechManager
    private lateinit var callingAgent: CallingAgent
    private lateinit var messageService: MessageService
    private lateinit var emergencyHandler: EmergencyHandler
    private lateinit var placeFinder: PlaceFinder
    private lateinit var searchService: SearchService
    private lateinit var reminderSet: ReminderSet

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        AndroidThreeTen.init(this)

        // Initialize health manager first
        healthAnalysisManager = HealthAnalysisManager(this)

        // Initialize components without dependencies first
        textToSpeechManager = TextToSpeechManager(this)
        reminderSet = ReminderSet(this, textToSpeechManager)

        // Initialize the main components without circular dependencies
        callingAgent = CallingAgent(
            context = this,
            readContactsPermissionRequestCode = READ_CONTACTS_PERMISSION_REQUEST_CODE,
            textToSpeechManager = textToSpeechManager
        )

        messageService = MessageService(
            context = this,
            onStatusUpdate = viewModel::updateStatusText,
            textToSpeechManager = textToSpeechManager,
            requestSmsPermission = { requestSmsPermission() }
        )

        emergencyHandler = EmergencyHandler(
            context = this,
            textToSpeechManager = textToSpeechManager
        )

        // Set up the dependencies after all components are created
        emergencyHandler.setDependencies(callingAgent, messageService)

        // Initialize remaining components
        placeFinder = PlaceFinder(this, callingAgent)
        searchService = SearchService(
            tavilyApiKey = "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",
            geminiApiKey = "AIzaSyDESVRn8spVAygvw2ewayvt1PTq56NrfP8",
            textToSpeechManager = textToSpeechManager
        )

        // Request necessary permissions
        if (ActivityCompat.checkSelfPermission(
                this,
                Manifest.permission.ACCESS_FINE_LOCATION
            ) != PackageManager.PERMISSION_GRANTED
        ) {
            ActivityCompat.requestPermissions(
                this,
                arrayOf(Manifest.permission.ACCESS_FINE_LOCATION),
                LOCATION_PERMISSION_REQUEST_CODE
            )
        }

        if (ActivityCompat.checkSelfPermission(
                this,
                Manifest.permission.WRITE_CALENDAR
            ) != PackageManager.PERMISSION_GRANTED
        ) {
            ActivityCompat.requestPermissions(
                this,
                arrayOf(
                    Manifest.permission.READ_CALENDAR,
                    Manifest.permission.WRITE_CALENDAR
                ),
                CALENDAR_PERMISSION_REQUEST_CODE
            )
        }

        requestContactsPermission()

        setContent {
            ElderlyAssistantTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = Color(0xFF111827)
                ) {
                    MainScreen(
                        onMicClick = { startSpeechRecognition() },
                        viewModel = viewModel
                    )
                }
            }
        }
    }

    private fun requestContactsPermission() {
        if (ContextCompat.checkSelfPermission(
                this,
                Manifest.permission.READ_CONTACTS
            ) != PackageManager.PERMISSION_GRANTED
        ) {
            ActivityCompat.requestPermissions(
                this,
                arrayOf(Manifest.permission.READ_CONTACTS),
                READ_CONTACTS_PERMISSION_REQUEST_CODE
            )
        }
    }

    private fun requestSmsPermission() {
        ActivityCompat.requestPermissions(
            this,
            arrayOf(Manifest.permission.SEND_SMS),
            SMS_PERMISSION_REQUEST_CODE
        )
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        when (requestCode) {
            SMS_PERMISSION_REQUEST_CODE -> {
                if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    viewModel.updateStatusText("SMS permission granted. You can now send messages.")
                } else {
                    viewModel.updateStatusText("SMS permission denied. I won't be able to send messages.")
                }
            }
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        when (requestCode) {
            SPEECH_REQUEST_CODE -> {
                if (resultCode == RESULT_OK) {
                    val spokenText: String? =
                        data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.let { results ->
                            results[0]
                        }
                    spokenText?.let {
                        viewModel.updateStatusText("You said: $it")
                        processVoiceCommand(it)
                    } ?: viewModel.updateStatusText("Sorry, I didn't catch that. Please try again.")
                } else {
                    viewModel.updateStatusText("Speech recognition failed or was cancelled. Please try again.")
                }
            }
        }
    }

    private fun startSpeechRecognition() {
        viewModel.updateStatusText("Listening...")
        viewModel.updateLlmResponse(null)
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(
                RecognizerIntent.EXTRA_LANGUAGE_MODEL,
                RecognizerIntent.LANGUAGE_MODEL_FREE_FORM
            )
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault())
            putExtra(RecognizerIntent.EXTRA_PROMPT, "Speak now")
        }
        startActivityForResult(intent, SPEECH_REQUEST_CODE)
    }

    private fun processVoiceCommand(command: String) {
        viewModel.updateStatusText("Processing your command...")
        val generativeModel = GenerativeModel(
            modelName = "gemini-1.5-flash",
            apiKey = "AIzaSyDESVRn8spVAygvw2ewayvt1PTq56NrfP8"
        )

        lifecycleScope.launch {
            try {
                val prompt = """
                Analyze this voice command and determine if it's:
                1. A request to make a phone call to a contact (respond with 'Call: [name]')
                2. A request to find and call a nearby place. Check for these types:
                   - Restaurant (respond with 'Place: restaurant')
                   - Hospital (respond with 'Place: hospital')
                   - Pharmacy (respond with 'Place: pharmacy')
                   - Clinic (respond with 'Place: clinic')
                   - Doctor (respond with 'Place: doctor')
                3. A request to set a reminder. Look for:
                   - Task/Activity
                   - Time (in 12-hour format with am/pm)
                   - Frequency (if mentioned: daily, weekly, monthly)
                   Respond with 'Reminder: [task] at [time] [frequency]'
                   Examples:
                   - "Reminder: take medicine at 9:00 am daily"
                   - "Reminder: call mom at 3:00 pm"
                   - "Reminder: doctor appointment at 2:30 pm"
                4. A question seeking information (respond with 'Search: [question]')
                5. A request to send a message (respond with 'Message: [recipient]|[message]')
                6. An emergency situation (respond with 'Emergency: [description]')
                7. A health-related query or statement (respond with 'Health: [query]')
                8. For any other command, respond with 'Unknown'

                Command: $command
                """.trimIndent()

                val response = generativeModel.generateContent(prompt)
                val aiResponse = response.text?.trim() ?: "Error processing command"
                viewModel.updateLlmResponse("LLM Response: $aiResponse")

                when {
                    aiResponse.startsWith("Call: ") -> {
                        val contactName = aiResponse.substringAfter("Call: ")
                        viewModel.updateStatusText("Attempting to call $contactName")
                        callingAgent.searchContactAndCall(contactName, viewModel::updateStatusText)
                    }
                    aiResponse.startsWith("Place: ") -> {
                        val placeType = aiResponse.substringAfter("Place: ")
                        findAndCallPlace(placeType)
                    }
                    aiResponse.startsWith("Reminder: ") -> {
                        if (ContextCompat.checkSelfPermission(
                                this@MainActivity,
                                Manifest.permission.WRITE_CALENDAR
                            ) == PackageManager.PERMISSION_GRANTED
                        ) {
                            val success = reminderSet.parseAndSetReminder(aiResponse)
                            if (!success) {
                                viewModel.updateStatusText("Sorry, I couldn't set the reminder. Please try again.")
                                textToSpeechManager.speak("I'm sorry, but I couldn't set the reminder. Please try again.")
                            }
                        } else {
                            viewModel.updateStatusText("I don't have permission to set reminders. Please grant calendar permissions in settings.")
                            textToSpeechManager.speak("I'm sorry, but I don't have permission to set reminders. Please grant calendar permissions in the app settings.")
                        }
                    }
                    aiResponse.startsWith("Search: ") -> {
                        val query = aiResponse.substringAfter("Search: ")
                        lifecycleScope.launch {
                            searchService.handleSearchQuery(query)
                        }
                    }
                    aiResponse.startsWith("Message: ") -> {
                        val parts = aiResponse.substringAfter("Message: ").split("|")
                        if (parts.size == 2) {
                            val (recipient, message) = parts
                            messageService.handleMessageRequest(recipient, message)
                        } else {
                            viewModel.updateStatusText("Sorry, I couldn't understand the message request.")
                        }
                    }
                    aiResponse.startsWith("Emergency: ") -> {
                        val situation = aiResponse.substringAfter("Emergency: ")
                        viewModel.updateStatusText("Initiating emergency protocol...")
                        emergencyHandler.handleEmergency(situation)
                    }
                    aiResponse.startsWith("Health: ") -> {
                        val healthQuery = aiResponse.substringAfter("Health: ")
                        viewModel.updateStatusText("Analyzing your health data...")
                        lifecycleScope.launch {
                            val analysis = healthAnalysisManager.analyzeHealth(healthQuery, this@MainActivity)
                            viewModel.updateStatusText(analysis)
                            textToSpeechManager.speak(analysis)
                        }
                    }
                    else -> {
                        viewModel.updateStatusText("Command not recognized. Please try again.")
                    }
                }
            } catch (e: Exception) {
                viewModel.updateStatusText("Error: ${e.message}")
                viewModel.updateLlmResponse(null)
                Log.e(TAG, "Error in processVoiceCommand: ${e.message}")
            }
        }
    }

    private fun findAndCallPlace(placeTypeStr: String) {
        val placeType = PlaceFinder.PlaceType.fromString(placeTypeStr)
        if (placeType == null) {
            viewModel.updateStatusText("Sorry, I don't know how to find that type of place.")
            return
        }

        viewModel.updateStatusText("Searching for a nearby $placeTypeStr...")
        lifecycleScope.launch {
            try {
                Log.d(TAG, "Starting findAndCallPlace process for $placeTypeStr")
                val success = placeFinder.findNearbyPlaceAndCall(
                    placeType,
                    viewModel::updateStatusText,
                    viewModel::updateDebugInfo
                )
                if (!success) {
                    Log.e(TAG, "Failed to find or call a nearby $placeTypeStr")
                    viewModel.updateStatusText("Unable to find or call a nearby $placeTypeStr.")
                }
            } catch (e: Exception) {
                Log.e(TAG, "Error in findAndCallPlace: ${e.message}")
                viewModel.updateStatusText("An error occurred while searching for a $placeTypeStr: ${e.message}")
            }
        }
    }

    @Composable
    fun MainScreen(onMicClick: () -> Unit, viewModel: MainViewModel) {
        val statusText by viewModel.statusText.collectAsState()

        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp),
            contentAlignment = Alignment.Center
        ) {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(48.dp)
            ) {
                // Status Text
                Text(
                    text = statusText,
                    style = MaterialTheme.typography.headlineSmall,
                    color = Color(0xFFD1D5DB), // Light gray text
                    textAlign = TextAlign.Center
                )

                // Large Microphone Button
                IconButton(
                    onClick = onMicClick,
                    modifier = Modifier
                        .size(128.dp)
                        .background(
                            color = Color(0xFF2563EB), // Blue color
                            shape = CircleShape
                        )
                        .padding(24.dp)
                ) {
                    Icon(
                        imageVector = Icons.Filled.Mic,
                        contentDescription = "Microphone",
                        tint = Color.White,
                        modifier = Modifier.fillMaxSize()
                    )
                }
            }
        }
    }
}