package com.example.elderlyassistant

import android.content.Context
import android.speech.tts.TextToSpeech
import android.speech.tts.Voice
import java.util.*
import android.util.Log

class TextToSpeechManager(context: Context) : TextToSpeech.OnInitListener {
    private var textToSpeech: TextToSpeech? = null
    private var isInitialized = false
    private val speakQueue = mutableListOf<String>()

    companion object {
        private const val TAG = "TextToSpeechManager"
    }

    init {
        textToSpeech = TextToSpeech(context, this)
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            val result = textToSpeech?.setLanguage(Locale.getDefault())
            if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
                Log.e(TAG, "Language not supported")
            } else {
                isInitialized = true
                configureTTS()
                speakQueue.forEach { speak(it) }
                speakQueue.clear()
            }
        } else {
            Log.e(TAG, "Initialization failed")
        }
    }

    private fun configureTTS() {
        textToSpeech?.let { tts ->
            // Set a slower speech rate (0.8 is 80% of the normal rate)
            tts.setSpeechRate(1.1f)

            tts.setPitch(1.0f)

            // Try to set a male voice
            val maleVoice = tts.voices.find { it.name.contains("male", ignoreCase = true) }
            maleVoice?.let {
                tts.voice = it
                Log.d(TAG, "Set male voice: ${it.name}")
            } ?: Log.w(TAG, "No male voice found, using default")
        }
    }

    fun speak(text: String) {
        if (isInitialized) {
            Log.d(TAG, "Speaking: $text")
            textToSpeech?.speak(text, TextToSpeech.QUEUE_FLUSH, null, null)
        } else {
            Log.w(TAG, "TTS not initialized, queueing: $text")
            speakQueue.add(text)
        }
    }

    fun shutdown() {
        textToSpeech?.stop()
        textToSpeech?.shutdown()
        Log.d(TAG, "TTS shut down")
    }
}