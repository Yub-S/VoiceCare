package com.example.elderlyassistant

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.provider.ContactsContract
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class CallingAgent(
    private val context: Context,
    private val readContactsPermissionRequestCode: Int,
    private val textToSpeechManager: TextToSpeechManager
) {
    private val CALL_PERMISSION_REQUEST_CODE = 1
    private var _emergencyHandler: EmergencyHandler? = null

    fun setEmergencyHandler(handler: EmergencyHandler) {
        _emergencyHandler = handler
    }

    private val emergencyHandler: EmergencyHandler
        get() = _emergencyHandler ?: throw IllegalStateException("EmergencyHandler not initialized")

    fun searchContactAndCall(contactName: String, updateStatusText: (String) -> Unit) {
        CoroutineScope(Dispatchers.Main).launch {
            if (ContextCompat.checkSelfPermission(context, Manifest.permission.READ_CONTACTS) == PackageManager.PERMISSION_GRANTED) {
                var phoneNumber = getPhoneNumberFromName(contactName, updateStatusText)
                if (phoneNumber != null) {
                    updateStatusText("Found contact. Initiating call...")
                    textToSpeechManager.speak("Found contact. Initiating call to $contactName.")
                    initiateCall(phoneNumber, updateStatusText)
                } else {
                    updateStatusText("Contact not found: $contactName")
                    textToSpeechManager.speak("Sorry, I couldn't find $contactName in your contacts. Can you please say the name again?")
                    val newName = emergencyHandler.listenForResponse()
                    if (newName.toLowerCase() != "cancel") {
                        searchContactAndCall(newName, updateStatusText)
                    } else {
                        updateStatusText("Call request canceled.")
                        textToSpeechManager.speak("Call request canceled.")
                    }
                }
            } else {
                updateStatusText("Contacts permission not granted")
                textToSpeechManager.speak("Contacts permission not granted. Please grant permission to access contacts.")
                requestContactsPermission()
            }
        }
    }

    private fun getPhoneNumberFromName(name: String, updateStatusText: (String) -> Unit): String? {
        val uri = ContactsContract.CommonDataKinds.Phone.CONTENT_URI
        val projection = arrayOf(
            ContactsContract.CommonDataKinds.Phone.NUMBER,
            ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME
        )
        val selection = "${ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME} LIKE ?"
        val selectionArgs = arrayOf("%$name%")
        var phoneNumber: String? = null

        context.contentResolver.query(uri, projection, selection, selectionArgs, null)?.use { cursor ->
            if (cursor.moveToFirst()) {
                val numberIndex = cursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.NUMBER)
                if (numberIndex != -1) {
                    phoneNumber = cursor.getString(numberIndex)
                }
            }
        }

        updateStatusText(if (phoneNumber != null) "Found number for $name" else "No number found for $name")
        return phoneNumber
    }

    fun initiateCall(phoneNumber: String, updateStatusText: (String) -> Unit) {
        if (ContextCompat.checkSelfPermission(context, Manifest.permission.CALL_PHONE) != PackageManager.PERMISSION_GRANTED) {
            updateStatusText("Call permission not granted. Requesting permission...")
            textToSpeechManager.speak("Call permission not granted. Please grant permission to make calls.")
            ActivityCompat.requestPermissions(context as MainActivity, arrayOf(Manifest.permission.CALL_PHONE), CALL_PERMISSION_REQUEST_CODE)
        } else {
            updateStatusText("Initiating call...")
            textToSpeechManager.speak("Initiating call.")
            val intent = Intent(Intent.ACTION_CALL, Uri.parse("tel:$phoneNumber"))
            context.startActivity(intent)
        }
    }

    private fun requestContactsPermission() {
        ActivityCompat.requestPermissions(
            context as MainActivity,
            arrayOf(Manifest.permission.READ_CONTACTS),
            readContactsPermissionRequestCode
        )
    }
}