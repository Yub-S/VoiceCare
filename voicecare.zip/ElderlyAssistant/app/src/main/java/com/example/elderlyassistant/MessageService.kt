package com.example.elderlyassistant

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.provider.ContactsContract
import android.telephony.SmsManager
import android.util.Log
import androidx.core.content.ContextCompat
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

class MessageService(
    private val context: Context,
    private val onStatusUpdate: (String) -> Unit,
    private val textToSpeechManager: TextToSpeechManager,
    private val requestSmsPermission: () -> Unit
) {
    private val TAG = "MessageService"
    private var _emergencyHandler: EmergencyHandler? = null

    fun setEmergencyHandler(handler: EmergencyHandler) {
        _emergencyHandler = handler
    }

    protected val emergencyHandler: EmergencyHandler
        get() = _emergencyHandler ?: throw IllegalStateException("EmergencyHandler not initialized")

    suspend fun handleMessageRequest(recipient: String, message: String) {
        try {
            if (!checkSmsPermission()) {
                requestSmsPermission()
                val permissionMessage = "I need permission to send messages. Please grant the permission and try again."
                onStatusUpdate(permissionMessage)
                textToSpeechManager.speak(permissionMessage)
                return
            }

            var phoneNumber = findContactPhoneNumber(recipient)
            if (phoneNumber == null) {
                val notFoundMessage = "Sorry, I couldn't find $recipient in your contacts. Would you like to try another name? Say the name or 'cancel' to stop."
                onStatusUpdate(notFoundMessage)
                textToSpeechManager.speak(notFoundMessage)

                val newName = emergencyHandler.listenForResponse()
                if (newName.toLowerCase() != "cancel") {
                    handleMessageRequest(newName, message)
                    return
                } else {
                    val cancelMessage = "Message sending canceled."
                    onStatusUpdate(cancelMessage)
                    textToSpeechManager.speak(cancelMessage)
                    return
                }
            }

            sendSms(phoneNumber, message)

            val sentMessage = "Message sent to $recipient: $message"
            onStatusUpdate(sentMessage)
            textToSpeechManager.speak("Your message has been sent to $recipient")

        } catch (e: Exception) {
            val errorMessage = "Sorry, I couldn't send the message: ${e.message}"
            onStatusUpdate(errorMessage)
            textToSpeechManager.speak(errorMessage)
            Log.e(TAG, "Error in handleMessageRequest", e)
        }
    }

    private fun checkSmsPermission(): Boolean {
        return ContextCompat.checkSelfPermission(
            context,
            Manifest.permission.SEND_SMS
        ) == PackageManager.PERMISSION_GRANTED
    }

    private suspend fun findContactPhoneNumber(contactName: String): String? {
        return withContext(Dispatchers.IO) {
            try {
                val uri = ContactsContract.CommonDataKinds.Phone.CONTENT_URI
                val projection = arrayOf(
                    ContactsContract.CommonDataKinds.Phone.NUMBER,
                    ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME
                )
                val selection = "${ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME} LIKE ?"
                val selectionArgs = arrayOf("%$contactName%")

                context.contentResolver.query(
                    uri,
                    projection,
                    selection,
                    selectionArgs,
                    null
                )?.use { cursor ->
                    if (cursor.moveToFirst()) {
                        val phoneNumberIndex = cursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.NUMBER)
                        if (phoneNumberIndex >= 0) {
                            return@withContext cursor.getString(phoneNumberIndex)
                        } else {
                            Log.w(TAG, "Phone number column not found in cursor")
                            return@withContext null
                        }
                    } else {
                        Log.d(TAG, "No contacts found matching: $contactName")
                        return@withContext null
                    }
                }

                Log.d(TAG, "Cursor was null for contact query: $contactName")
                null
            } catch (e: Exception) {
                Log.e(TAG, "Error finding contact: $contactName", e)
                null
            }
        }
    }

    fun sendSms(phoneNumber: String, message: String) {
        try {
            val smsManager = context.getSystemService(SmsManager::class.java)
            smsManager.sendTextMessage(
                phoneNumber,
                null,
                message,
                null,
                null
            )
        } catch (e: Exception) {
            Log.e(TAG, "Error sending SMS", e)
            throw e
        }
    }
}
